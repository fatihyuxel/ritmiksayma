import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'dart:math';

void main() => runApp(const SayiOyunu());

class SayiOyunu extends StatelessWidget {
  const SayiOyunu({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const OyunEkrani(),
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.orange),
    );
  }
}

class OyunEkrani extends StatefulWidget {
  const OyunEkrani({Key? key}) : super(key: key);

  @override
  _OyunEkraniState createState() => _OyunEkraniState();
}

class ConfettiParticle {
  double x, y, vx, vy, size;
  Color color;
  ConfettiParticle(this.x, this.y, this.vx, this.vy, this.size, this.color);
}

class _OyunEkraniState extends State<OyunEkrani> with TickerProviderStateMixin {
  final FlutterTts tts = FlutterTts();
  final Random random = Random();

  int puan = 0;
  int dogruSayisi = 0;
  List<ConfettiParticle> konfetiler = [];
  late AnimationController konfettiController;
  bool konfettiGoster = false;
  bool cevaplandiMi = false;

  List<int> ardasikSayilar = [];
  int eksikIndex = 0;
  List<int> secenekler = [];

  final List<Color> renkler = [
    const Color(0xFFFF6B6B),
    const Color(0xFF4ECDC4),
    const Color(0xFFFFE066),
    const Color(0xFF6BCB77),
    const Color(0xFF4D96FF),
  ];

  final List<String> tebrikMesajlari = [
    "MUKEMMEL!",
    "COK GUZEL!",
    "AFERIN!",
    "HARIKA!",
    "BRAVO!",
    "SUPER!",
  ];

  final List<String> tebrikSesleri = [
    "m\u00fckemmel",
    "\u00e7ok g\u00fczel",
    "aferin",
    "harika",
    "bravo",
    "s\u00fcper",
  ];

  final Map<int, String> turkceOkunus = {
    1: "bir",
    2: "iki",
    3: "\u00fc\u00e7",
    4: "d\u00f6rt",
    5: "be\u015f",
    6: "alt\u0131",
    7: "yedi",
    8: "sekiz",
    9: "dokuz",
    10: "on",
    11: "on bir",
    12: "on iki",
    13: "on \u00fc\u00e7",
    14: "on d\u00f6rt",
    15: "on be\u015f",
    16: "on alt\u0131",
    17: "on yedi",
    18: "on sekiz",
    19: "on dokuz",
    20: "yirmi",
    21: "yirmi bir",
    22: "yirmi iki",
    23: "yirmi \u00fc\u00e7",
    24: "yirmi d\u00f6rt",
    25: "yirmi be\u015f",
    26: "yirmi alt\u0131",
    27: "yirmi yedi",
    28: "yirmi sekiz",
    29: "yirmi dokuz",
    30: "otuz",
    31: "otuz bir",
    32: "otuz iki",
    33: "otuz \u00fc\u00e7",
    34: "otuz d\u00f6rt",
    35: "otuz be\u015f",
    36: "otuz alt\u0131",
    37: "otuz yedi",
    38: "otuz sekiz",
    39: "otuz dokuz",
    40: "k\u0131rk",
    41: "k\u0131rk bir",
    42: "k\u0131rk iki",
    43: "k\u0131rk \u00fc\u00e7",
    44: "k\u0131rk d\u00f6rt",
    45: "k\u0131rk be\u015f",
    46: "k\u0131rk alt\u0131",
    47: "k\u0131rk yedi",
    48: "k\u0131rk sekiz",
    49: "k\u0131rk dokuz",
    50: "elli",
    51: "elli bir",
    52: "elli iki",
    53: "elli \u00fc\u00e7",
    54: "elli d\u00f6rt",
    55: "elli be\u015f",
    56: "elli alt\u0131",
    57: "elli yedi",
    58: "elli sekiz",
    59: "elli dokuz",
    60: "altm\u0131\u015f",
    61: "altm\u0131\u015f bir",
    62: "altm\u0131\u015f iki",
    63: "altm\u0131\u015f \u00fc\u00e7",
    64: "altm\u0131\u015f d\u00f6rt",
    65: "altm\u0131\u015f be\u015f",
    66: "altm\u0131\u015f alt\u0131",
    67: "altm\u0131\u015f yedi",
    68: "altm\u0131\u015f sekiz",
    69: "altm\u0131\u015f dokuz",
    70: "yetmi\u015f",
    71: "yetmi\u015f bir",
    72: "yetmi\u015f iki",
    73: "yetmi\u015f \u00fc\u00e7",
    74: "yetmi\u015f d\u00f6rt",
    75: "yetmi\u015f be\u015f",
    76: "yetmi\u015f alt\u0131",
    77: "yetmi\u015f yedi",
    78: "yetmi\u015f sekiz",
    79: "yetmi\u015f dokuz",
    80: "seksen",
    81: "seksen bir",
    82: "seksen iki",
    83: "seksen \u00fc\u00e7",
    84: "seksen d\u00f6rt",
    85: "seksen be\u015f",
    86: "seksen alt\u0131",
    87: "seksen yedi",
    88: "seksen sekiz",
    89: "seksen dokuz",
    90: "doksan",
    91: "doksan bir",
    92: "doksan iki",
    93: "doksan \u00fc\u00e7",
    94: "doksan d\u00f6rt",
    95: "doksan be\u015f",
    96: "doksan alt\u0131",
    97: "doksan yedi",
    98: "doksan sekiz",
    99: "doksan dokuz",
    100: "y\u00fcz",
  };

  @override
  void initState() {
    super.initState();
    tts.setLanguage("tr-TR");
    tts.setSpeechRate(0.5);
    tts.setPitch(1.0);
    konfettiController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    );
    konfettiController.addListener(() {
      if (konfettiGoster) {
        setState(() {
          for (var p in konfetiler) {
            p.x += p.vx;
            p.y += p.vy;
            p.vy += 0.3;
          }
        });
      }
    });
    yeniSoru();
  }

  @override
  void dispose() {
    konfettiController.dispose();
    super.dispose();
  }

  void yeniSoru() {
    // ✅ Eksik sayı hep 10'un katı olsun
    // 10'un katları: 10, 20, 30 ... 100
    // Eksik sayı bu katlardan biri olacak
    // 5 ardışık sayı içinde bu kat bulunacak
    // Örnek: eksik=30 → seri 28,29,30,31,32 veya 27,28,29,30,31 vb.

    List<int> onunKatlari =
        List.generate(10, (i) => (i + 1) * 10); // 10,20,...,100
    int eksikSayi = onunKatlari[random.nextInt(onunKatlari.length)];

    // Eksik sayının serinin kaçıncı sırasında olacağını rastgele seç
    int eksikPozisyon = random.nextInt(5); // 0,1,2,3,4
    int baslangic = eksikSayi - eksikPozisyon;

    // Sınır kontrolü
    if (baslangic < 1) baslangic = 1;
    if (baslangic + 4 > 100) baslangic = 96;

    ardasikSayilar = List.generate(5, (i) => baslangic + i);
    eksikIndex = ardasikSayilar.indexOf(eksikSayi);
    if (eksikIndex == -1) eksikIndex = 2; // güvenlik

    // 3 seçenek: doğru + 2 yanlış
    Set<int> yanlisSayilar = {};
    while (yanlisSayilar.length < 2) {
      int fark = random.nextInt(5) + 1;
      int yanlis = random.nextBool() ? eksikSayi + fark : eksikSayi - fark;
      if (yanlis != eksikSayi && yanlis >= 1 && yanlis <= 100) {
        yanlisSayilar.add(yanlis);
      }
    }
    secenekler = [eksikSayi, ...yanlisSayilar]..shuffle();

    setState(() {
      cevaplandiMi = false;
    });
  }

  void konfettiBaslat() {
    konfetiler = List.generate(80, (i) {
      return ConfettiParticle(
        random.nextDouble() * 400,
        -20,
        (random.nextDouble() - 0.5) * 6,
        random.nextDouble() * 4 + 2,
        random.nextDouble() * 10 + 5,
        renkler[random.nextInt(renkler.length)],
      );
    });
    setState(() => konfettiGoster = true);
    konfettiController.forward(from: 0);
    Future.delayed(const Duration(milliseconds: 2500), () {
      if (mounted) setState(() => konfettiGoster = false);
    });
  }

  // ✅ Tüm sayıları sırayla oku — her sayıdan sonra bekle
  Future<void> sayilariOku() async {
    for (int sayi in ardasikSayilar) {
      String okunusu = turkceOkunus[sayi] ?? sayi.toString();
      await tts.speak(okunusu);
      // TTS bitene kadar bekle
      await Future.delayed(Duration(milliseconds: okunusu.length * 120 + 600));
    }
  }

  void cevapSec(int sayi) {
    if (cevaplandiMi) return;
    int eksikSayi = ardasikSayilar[eksikIndex];

    if (sayi == eksikSayi) {
      int secilen = random.nextInt(tebrikMesajlari.length);
      setState(() {
        puan += 10;
        dogruSayisi += 1;
        cevaplandiMi = true;
      });
      konfettiBaslat();
      tts.speak(tebrikSesleri[secilen]);

      // ✅ Tebrik sesi bittikten sonra sayıları oku, sonra yeni soru
      Future.delayed(const Duration(milliseconds: 1200), () async {
        await sayilariOku();
        if (mounted) {
          await Future.delayed(const Duration(milliseconds: 500));
          yeniSoru();
        }
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Text("\u{1F31F} ", style: TextStyle(fontSize: 20)),
              Text(tebrikMesajlari[secilen],
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ),
          backgroundColor: const Color(0xFF6BCB77),
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          duration: const Duration(seconds: 5),
        ),
      );
    } else {
      tts.speak("tekrar dene");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(
            children: [
              Text("\u274C ", style: TextStyle(fontSize: 20)),
              Text("Tekrar deneyelim!",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ),
          backgroundColor: Colors.redAccent,
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          duration: const Duration(milliseconds: 1500),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFFFF9C4), Color(0xFFE0F7FA)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFF6B6B),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.red.withValues(alpha: 0.3),
                                blurRadius: 8,
                                offset: const Offset(0, 4))
                          ],
                        ),
                        child: Row(children: [
                          const Text("\u2B50 ", style: TextStyle(fontSize: 18)),
                          Text("$puan",
                              style: const TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white)),
                        ]),
                      ),
                      const Text("Say\u0131 Oyunu",
                          style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              color: Color(0xFF4ECDC4))),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF6BCB77),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.green.withValues(alpha: 0.3),
                                blurRadius: 8,
                                offset: const Offset(0, 4))
                          ],
                        ),
                        child: Row(children: [
                          const Text("\u2705 ", style: TextStyle(fontSize: 18)),
                          Text("$dogruSayisi",
                              style: const TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white)),
                        ]),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text("Eksik say\u0131y\u0131 bul!",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF4ECDC4))),
                      const SizedBox(height: 30),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(5, (index) {
                            bool eksik = index == eksikIndex;
                            Color renk = renkler[index];
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 4),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 300),
                                width: 58,
                                height: 70,
                                decoration: BoxDecoration(
                                  color: eksik ? Colors.white : renk,
                                  border: Border.all(
                                    color:
                                        eksik ? const Color(0xFFFF6B6B) : renk,
                                    width: eksik ? 3 : 2,
                                  ),
                                  borderRadius: BorderRadius.circular(14),
                                  boxShadow: [
                                    BoxShadow(
                                      color: eksik
                                          ? Colors.red.withValues(alpha: 0.2)
                                          : renk.withValues(alpha: 0.4),
                                      blurRadius: 8,
                                      offset: const Offset(0, 4),
                                    )
                                  ],
                                ),
                                child: Center(
                                  child: eksik
                                      ? const Text("?",
                                          style: TextStyle(
                                              fontSize: 32,
                                              fontWeight: FontWeight.w900,
                                              color: Color(0xFFFF6B6B)))
                                      : Text("${ardasikSayilar[index]}",
                                          style: const TextStyle(
                                              fontSize: 28,
                                              fontWeight: FontWeight.w900,
                                              color: Colors.white)),
                                ),
                              ),
                            );
                          }),
                        ),
                      ),
                      const SizedBox(height: 50),
                      const Text("Hangi say\u0131?",
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.grey)),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: secenekler.map((sayi) {
                          int idx = secenekler.indexOf(sayi);
                          Color renk = [
                            const Color(0xFF9B5DE5),
                            const Color(0xFFFF9F1C),
                            const Color(0xFF4D96FF),
                          ][idx % 3];
                          return Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            child: GestureDetector(
                              onTap: () => cevapSec(sayi),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 150),
                                width: 80,
                                height: 80,
                                decoration: BoxDecoration(
                                  color: renk,
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: [
                                    BoxShadow(
                                        color: renk.withValues(alpha: 0.5),
                                        blurRadius: 10,
                                        offset: const Offset(0, 5))
                                  ],
                                ),
                                child: Center(
                                  child: Text("$sayi",
                                      style: const TextStyle(
                                          fontSize: 30,
                                          fontWeight: FontWeight.w900,
                                          color: Colors.white)),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 40),
                      TextButton.icon(
                        onPressed: yeniSoru,
                        icon: const Icon(Icons.refresh, color: Colors.grey),
                        label: const Text("Atla",
                            style: TextStyle(color: Colors.grey)),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (konfettiGoster)
            Positioned.fill(
              child: IgnorePointer(
                child: CustomPaint(painter: KonfettiPainter(konfetiler)),
              ),
            ),
        ],
      ),
    );
  }
}

class KonfettiPainter extends CustomPainter {
  final List<ConfettiParticle> parcaciklar;
  KonfettiPainter(this.parcaciklar);

  @override
  void paint(Canvas canvas, Size size) {
    for (var p in parcaciklar) {
      final paint = Paint()..color = p.color;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(p.x, p.y, p.size, p.size * 0.6),
          const Radius.circular(2),
        ),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(KonfettiPainter oldDelegate) => true;
}
