package com.example.yazma

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
